/**
 * ====================================================
 * PRODUCTS PAGE - PÁGINA DE GESTÃO DE PRODUTOS
 * ====================================================
 * 
 * Esta página centraliza a gestão de produtos, permitindo a listagem,
 * visualização detalhada, criação, edição, remoção e gestão de stock.
 * Implementa integração com o formulário multi-step e confirmação de stock.
 */

import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  Package, 
  AlertTriangle,  
  ArrowUpCircle,
  ArrowDownCircle,
  CheckCircle2, ShieldCheck 

} from "lucide-react"; // importaçãqo de icones do lucide-react

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";// Componentes de Card da UI
import { Button } from "@/components/ui/button";// Componente de Botão da UI
import { Badge } from "@/components/ui/badge";// componente de Badge da UI
import {
  AlertDialog, 
  AlertDialogAction, 
  AlertDialogCancel,
  AlertDialogContent, 
  AlertDialogDescription,
  AlertDialogFooter, 
  AlertDialogHeader, 
  AlertDialogTitle
} from "@/components/ui/alert-dialog"; // Componentes de AlertDialog da UI

import DataTable from "@/components/common/DataTable";// Componente de Tabela de Dados da UI
import ModalForm from "@/components/forms/ModalForm";// Componente de Modal de Formulário da UI
import GenericViewModal from "@/components/forms/GenericViewModal";// Componente de Modal de Visualização Genérica da UI

import { showSuccessToast, showErrorToast } from "@/utils/toast";// Funções utilitárias para exibir toasts de sucesso e erro
import { useProductService, type Product, type ProductFormData, type StockDTO } from "./ProductsService";// Hook customizado para interagir com o serviço de produtos
import ProductForm, { type ProductFormRef } from "./productForm";// Componente de Formulário de Produto e sua referencia
import StockForm, { type StockFormRef } from "./StockForm";// Componente de Formulário de Stock e sua referencia

const ProductsPage: React.FC = () => {

  // ====================================================
  // ESTADOS (STATE)
  // ====================================================
  
  const [products, setProducts] = useState<Product[]>([]);// Estado para armazenar a lista de produtos
  const [loading, setLoading] = useState(true);// Estado para controlar o carregamento da página

  // Modais de Produto
  const [modalOpen, setModalOpen] = useState(false);// Estado para controlar a abertura do modal de criação/edição de produto
  const [isEditMode, setIsEditMode] = useState(false);// Estado para controlar se o modal está em modo de edição ou criação
  const [formLoading, setFormLoading] = useState(false);// Estado para controlar o carregamento do formulário de produto
  const [currentProduct, setCurrentProduct] = useState<ProductFormData | undefined>(undefined);// Estado para armazenar os dados do produto atualmente selecionado para edição
  
  // Modais de Stock
  type StockConfirmPayload = {
    distribuicaoStock: StockDTO[];
  };// Tipo para armazenar os dados de confirmação de stock

  const [stockModalOpen, setStockModalOpen] = useState(false);// Estado para controlar a abertura do modal de gestão de stock
  const [stockMode, setStockMode] = useState<'adicionar' | 'baixar'>('adicionar');// Estado para controlar o modo de gestão de stock (adicionar ou baixar)
  const [selectedProductId, setSelectedProductId] = useState<string | number | null>(null);// Estado para armazenar o ID do produto selecionado para gestão de stock
  const [stockConfirmOpen, setStockConfirmOpen] = useState(false);// Estado para controlar a abertura do modal de confirmação de stock
  const [stockConfirmData, setStockConfirmData] = useState<StockConfirmPayload | null>(null);// Estado para armazenar os dados de confirmação de stock

  // Modal de Visualização e Exclusão
  const [viewProduct, setViewProduct] = useState<Product | null>(null);// Estado para armazenar os dados do produto atualmente selecionado para visualização
  const [showViewModal, setShowViewModal] = useState(false);// Estado para controlar a abertura do modal de visualização de produto
  const [deleteProduct, setDeleteProduct] = useState<Product | null>(null);// Estado para armazenar os dados do produto atualmente selecionado para exclusão
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);//  Estado para controlar a abertura do diálogo de confirmação de exclusão

  const productFormRef = useRef<ProductFormRef>(null);// Referência para o formulário de produto, permitindo acesso a métodos internos do componente
  const stockFormRef = useRef<StockFormRef>(null);//    Referência para o formulário de stock, permitindo acesso a métodos internos do componente

  const { listar, criar, editar, deletar, listarId, updateStock } = useProductService();// Hook customizado para interagir com o serviço de produtos, fornecendo métodos para listar, criar, editar, deletar e atualizar stock

  // ====================================================
  // CARREGAMENTO DE DADOS (FETCH)
  // ====================================================

  const fetchProducts = async () => {// Função para carregar a lista de produtos do serviço
    setLoading(true);// Define o estado de carregamento como verdadeiro antes de iniciar a requisição
    try {
      const data = await listar();// Chama o método listar do serviço de produtos para obter a lista de produtos
      setProducts(Array.isArray(data) ? data : []);// Atualiza o estado de produtos com os dados recebidos, garantindo que seja um array
    } catch (error) {
      console.error("Erro ao carregar produtos", error);// Loga o erro no console para depuração
      showErrorToast("Erro ao carregar a lista de produtos.");// Exibe um toast de erro para o usuário
    } finally {// Garante que o estado de carregamento seja definido como falso após a conclusão da requisição, independentemente do sucesso ou falha
      setLoading(false);// Define o estado de carregamento como falso após a conclusão da requisição
    }
  };

  useEffect(() => {// Efeito para carregar os produtos quando o componente é montado
    fetchProducts();//  Chama a função fetchProducts para carregar a lista de produtos
  }, []);// O array de dependências vazio garante que o efeito seja executado apenas uma vez, quando o componente é montado

  // ====================================================
  // CÁLCULOS DE RESUMO (SUMMARY)
  // ====================================================

  const summary = useMemo(() => {// Calcula os resumos de stock e valores totais com base na lista de produtos
  const total = products.length;// Calcula o total de produtos na lista

  //Filtrar apenas produtos que CONTROLAM stock para as estatísticas de alerta
    const stockBaixo = products.filter(p => p.controlaStock && p.stock <= p.stockMin).length;// Conta quantos produtos estão com stock baixo (stock <= stockMin) e que controlam stock
const semStock = products.filter(p => p.controlaStock && p.stock === 0).length;// Conta quantos produtos estão sem stock (stock === 0) e que controlam stock
const stockOk = products.filter(p => !p.controlaStock || (p.stock > p.stockMin && p.stock > 0)).length;// Conta quantos produtos estão com stock OK (stock > stockMin e stock > 0) ou que não controlam stock
  const valorTotal = products.reduce((acc, p) => { // Calcula o valor total do stock multiplicando o preço unitário pelo stock disponível
    const preco = typeof p.precoUnitario === 'string'// Se o preço unitário for uma string, converte para número, removendo caracteres não numéricos e tratando vírgulas e pontos
      ? parseFloat(p.precoUnitario.replace(/[^\d,.-]/g, "").replace(/\./g, "").replace(",", "."))// Converte vírgulas para pontos para garantir a conversão correta para número
      : p.precoUnitario;// Se o preço unitário já for um número, usa diretamente

    return acc + (preco * p.stock);// Acumula o valor total multiplicando o preço pelo stock
  }, 0);

  const percentStockBaixo = total > 0 // Calcula a porcentagem de produtos com stock baixo em relação ao total de produtos
    ? ((stockBaixo / total) * 100).toFixed(1)// 1 casa decimal
    : 0;

  return { total, stockBaixo, semStock, valorTotal, percentStockBaixo, stockOk };// Retorna um objeto com os resumos calculados
}, [products]);

  // ====================================================
  // AÇÕES (HANDLERS)
  // ====================================================

  const handleCreate = () => { // Função para abrir o modal de criação de produto
    setCurrentProduct(undefined);// Limpa o estado do produto atual para garantir que o formulário esteja vazio
    setIsEditMode(false);// Define o modo de edição como falso, indicando que estamos criando um novo produto
    setModalOpen(true);// Abre o modal de criação de produto
    setTimeout(() => productFormRef.current?.resetStep(), 0);// Garante que o formulário volte ao primeiro passo do multi-step form após abrir o modal
  };

  const handleEdit = useCallback(async (product: Product) => { // Função para abrir o modal de edição de produto, carregando os dados do produto selecionado
  try {
    setFormLoading(true);// Define o estado de carregamento do formulário como verdadeiro enquanto os dados são carregados

    // 1. Verificamos se o ID existe antes de chamar a API
    const idParaBuscar = product.id || (product as Product & { ID?: string | number }).ID;// Tenta obter o ID do produto, seja pelo campo 'id' ou 'ID' (caso a API retorne com outro nome)
    if (!idParaBuscar) {// Se não houver ID, exibe um erro e retorna
      showErrorToast("ID do produto não encontrado.");
      return;
    }
    const response = await listarId(idParaBuscar);// Chama a função listarId para obter os dados completos do produto selecionado

    // 2. Tratamos se a API devolver um array [0] ou objeto direto
    const res = Array.isArray(response) ? response[0] : response;// Garante que temos um objeto de produto, mesmo que a API retorne um array

    if (!res) {// Se não houver dados, exibe um erro e retorna
      showErrorToast("Não foi possível encontrar os dados deste produto.");
      return;
    }

    // 3. Mapeamento fiel aos campos que o seu FORMULÁRIO espera
    const mapped: ProductFormData = { // Mapeia os dados recebidos da API para o formato esperado pelo formulário
      id: res.id,
      codigobarra: res.codigobarra || '',
      nome: res.nome || '',
      descricao: res.descricao || '',
      controlaStock: res.controlaStock,
      precoUnitario: String(res.precoUnitario || '0'),
      categoria: res.idcatgory ? { id: res.idcatgory, nome: res.categorys || '' } : null,
      fornacedor: res.idsupplier ? { id: res.idsupplier, nome: res.suppliers || '' } : null,
      imposto: res.idtax ? { id: res.idtax, nome: res.taxs || '' } : null,
      imagem: res.logoUrl || null,
      distribuicaoStock: [],
    };

    setCurrentProduct(mapped);// Atualiza o estado do produto atual com os dados mapeados para o formulário
  setIsEditMode(true);// Define o modo de edição como verdadeiro, indicando que estamos editando um produto existente
    setModalOpen(true);// Abre o modal de edição de produto

    // Garantimos que o formulário volta ao primeiro passo
    setTimeout(() => {// Usamos setTimeout para garantir que o resetStep seja chamado após o modal abrir
      productFormRef.current?.resetStep();// Chama o método resetStep do formulário para voltar ao primeiro passo do multi-step form
    }, 50);

  } catch (error) {
    console.error("Erro no mapeamento de edição:", error);
    showErrorToast("Erro ao carregar dados do produto.");
  } finally {
    setFormLoading(false);
  }
}, [listarId]);// O useCallback garante que a função seja memoizada e não recriada em cada renderização, evitando loops desnecessários

const handleViewClick = useCallback(async (product: Product) => {// Função para abrir o modal de visualização de produto, carregando os dados do produto selecionado
  try {
   
    const res = await listarId(product.id);// Chama a função listarId para obter os dados completos do produto selecionado
 
    const dadosFinais = Array.isArray(res) ? res[0] : res;//  Garante que temos um objeto de produto, mesmo que a API retorne um array

    if (!dadosFinais) {
      showErrorToast("Produto não encontrado no servidor.");
      return;
    }

    setViewProduct(dadosFinais);// Atualiza o estado do produto a ser visualizado com os dados recebidos da API
    setShowViewModal(true);// Abre o modal de visualização de produto
  } catch (error) {
    console.error("Erro no listarId:", error);
    showErrorToast("Erro ao carregar detalhes para visualização.");
  }
}, [listarId]);// O useCallback garante que a função seja memoizada e não recriada em cada renderização, evitando loops desnecessários

  const handleDeleteClick = useCallback((product: Product) => {
    setDeleteProduct(product);
    setShowDeleteDialog(true);
  }, []);

  const handleDeleteConfirm = async () => {
    if (!deleteProduct) return;
    try {
      await deletar(deleteProduct.id);
      showSuccessToast(`Produto "${deleteProduct.nome}" removido com sucesso.`);
      fetchProducts();
    } catch (error) {
      showErrorToast("Erro ao tentar remover o produto.");
    } finally {
      setShowDeleteDialog(false);
      setDeleteProduct(null);
    }
  };

  const handleSubmit = async () => {// Função para lidar com o envio do formulário de criação/edição de produto
    if (!productFormRef.current) return;// Verifica se a referência do formulário está disponível antes de prosseguir

    const isValid = await productFormRef.current.trigger();
    if (!isValid) {
      showErrorToast("Por favor, preencha todos os campos obrigatórios.");
      return;
    }

    const data = productFormRef.current.getValues();// Obtém os valores do formulário, que devem estar no formato ProductFormData
    setFormLoading(true);

    try {
      if (isEditMode) {
        await editar(data);
        showSuccessToast(`Produto "${data.nome}" atualizado com sucesso!`);
      } else {
        await criar(data);
        showSuccessToast(`Produto "${data.nome}" cadastrado com sucesso!`);
      }
      setModalOpen(false);
      fetchProducts();
    } catch (error) {
      // Erro tratado no service
    } finally {
      setFormLoading(false);
    }
  };

  // Handlers de Stock
  const handleOpenStock = useCallback((product: Product, mode: 'adicionar' | 'baixar') => { // Função para abrir o modal de gestão de stock, definindo o produto selecionado e o modo (adicionar ou baixar)
    if (!product.controlaStock) { // Se o produto não controla stock, exibe um alerta e aborta a operação
       showErrorToast("Este produto é de fluxo livre e não gere stock."); // Alerta que serviços não precisam de stock
       return; // Aborta
    }
    
    setSelectedProductId(product.id);
    setStockMode(mode);
    setStockModalOpen(true);
  }, []);

  const handleStockSubmit = async () => {// Função para lidar com o envio do formulário de gestão de stock
    if (!stockFormRef.current) return;
    const isValid = await stockFormRef.current.trigger();// Valida os campos do formulário de stock antes de prosseguir
    if (!isValid) return;

    const data = stockFormRef.current.getValues() as StockConfirmPayload;// Obtém os valores do formulário de stock, que devem estar no formato StockConfirmPayload
    setStockConfirmData(data);
    setStockConfirmOpen(true);
  };

  const handleConfirmStockUpdate = async () => {
    if (!stockConfirmData) return;
    setFormLoading(true);
    try {
      const stockPayload = stockConfirmData.distribuicaoStock.map(item => ({
        storeId: item.storeId ?? item.storeName,
        storeName: item.storeName,
        stock: item.stock,
        stockMin: item.stockMin,
        productId: item.productId
      }));

      await updateStock({
        acao: stockMode,
        distribuicaoStock: stockPayload
      });
      showSuccessToast("Stock atualizado com sucesso!");
      setStockModalOpen(false);
      setStockConfirmOpen(false);
      fetchProducts();
    } catch (error) {
      // Erro tratado no service
    } finally {
      setFormLoading(false);
    }
  };

  // ====================================================
  // CONFIGURAÇÃO DA TABELA
  // ====================================================

  const columns = useMemo(() => [
{
    // Mude de Key para key (minúsculo)
    key: "codigobarra" as keyof Product, 
    label: "Código de Barras",
    sortable: true,
    render: (value: string | number | boolean | null | undefined) => (
      <span className="text-sm text-muted-foreground">{value}</span>
    )
  },
    {
      key: "nome" as keyof Product,
      label: "Produto",
      sortable: true,
      render: (value: string | number | boolean | null | undefined) => <div className="font-medium">{value}</div>
    },
    { key: "categorys" as keyof Product, label: "Categoria" },
    { 
      key: "precoUnitario" as keyof Product, 
      label: "Preço",
      render: (value: string | number | boolean | null | undefined) => <span className="font-semibold">{value} Db</span>
    },
   { 
      key: "stock" as keyof Product, 
      label: "Stock",
      // Usando exatamente o tipo que o DataTable exige para a row
      render: (
        value: string | number | boolean | null | undefined, 
        row: Record<string, string | number | boolean | null | undefined>
      ) => {
       if (row.controlaStock === false) { // Se a flag de controlo for falsa no Back
          return <Badge className="bg-blue-100 text-blue-700 border-blue-200 shadow-none"><ShieldCheck size={10} className="mr-1"/> LIVRE</Badge>; // Mostra emblema azul
        }
        const stock = Number(value) || 0; // Quantidade atual
        const stockMin = Number(row.stockMin) || 0; // Quantidade mínima
        const isLow = stock <= stockMin; // Verifica se está baixo
        return ( // Retorna Badge de quantidade
          <div className="flex items-center gap-2">
            <Badge variant={isLow ? "destructive" : "secondary"}>{stock}</Badge> 
            {isLow && <AlertTriangle className="w-4 h-4 text-orange-500 animate-pulse" />} 
          </div>
        );
      }
    }
  ], []); // Dependência vazia

  const actions = useMemo(() => [
    {
      label: "Visualizar",
   icon: Eye,
    onClick: (row: Record<string, string | number | boolean | null | undefined>) => handleViewClick(row as unknown as Product)
    },  
    {
      label: "Editar",
       icon: Edit,
    onClick: (row: Record<string, string | number | boolean | null | undefined>) => handleEdit(row as unknown as Product)
    }, 
    {
      label: "Aumentar Stock",
     icon: ArrowUpCircle,
      onClick: (row: Record<string, string | number | boolean | null | undefined>) => handleOpenStock(row as unknown as Product, 'adicionar')

    },
    {
      label: "Baixar Stock",
     icon: ArrowDownCircle,
      onClick: (row: Record<string, string | number | boolean | null | undefined>) => handleOpenStock(row as unknown as Product, 'baixar')
    },
    {
      label: "Eliminar",
     icon: Trash2,
      onClick: (row: Record<string, string | number | boolean | null | undefined>) => handleDeleteClick(row as unknown as Product)
    }
 ], [handleViewClick, handleEdit, handleOpenStock, handleDeleteClick]);

  return (
    <div className="p-6 space-y-6">
      {/* Cabeçalho e Resumos */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Gestão de Produtos</h1>
          <p className="text-muted-foreground text-sm">Controle de inventário, preços e distribuição por loja.</p>
        </div>
        <Button onClick={handleCreate} className="flex items-center gap-2">
          <Plus className="w-4 h-4" /> Novo Produto
        </Button>
      </div>
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">

  {/* Total */}
  <Card>
    <CardContent className="pt-6 flex justify-between items-center">
      <div>
        <p className="text-xs text-muted-foreground uppercase">Total</p>
        <h3 className="text-2xl font-bold">{summary.total}</h3>
      </div>
      <Package className="h-8 w-8 text-blue-500" />
    </CardContent>
  </Card>

  {/* Stock Baixo */}
  <Card>
    <CardContent className="pt-6 flex justify-between items-center">
      <div>
        <p className="text-xs text-muted-foreground uppercase">Stock Baixo</p>
        <h3 className="text-2xl font-bold">{summary.stockBaixo}</h3>
      </div>
      <AlertTriangle className="h-8 w-8 text-orange-500" />
    </CardContent>
  </Card>

  {/* Sem Stock */}
  <Card>
    <CardContent className="pt-6 flex justify-between items-center">
      <div>
        <p className="text-xs text-muted-foreground uppercase">Sem Stock</p>
        <h3 className="text-2xl font-bold">{summary.semStock}</h3>
      </div>
      <ArrowDownCircle className="h-8 w-8 text-red-500" />
    </CardContent>
  </Card>

  {/* Stock OK */}
  <Card>
    <CardContent className="pt-6 flex justify-between items-center">
      <div>
        <p className="text-xs text-muted-foreground uppercase">Stock OK</p>
        <h3 className="text-2xl font-bold">{summary.stockOk}</h3>
      </div>
      <CheckCircle2 className="h-8 w-8 text-green-500" />
    </CardContent>
  </Card>

</div>

      {/* Tabela de Dados */}
      <Card>
         <CardHeader>
                  <CardTitle>Lista de Produtos</CardTitle>
                  <CardDescription>
                    {products.length} produto(s) encontrada(s) no sistema.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <DataTable
                    data={products as unknown as Record<string, string | number | boolean | null | undefined>[]}
                    columns={columns}
                    actions={actions}
                    loading={loading}
                    searchable
                    searchPlaceholder="Pesquisar por nome ou código...."
                    emptyMessage="Nenhum produto encontrado."
                    paginated={true}
                    pageSize={10}
                  />
                </CardContent>

       
      </Card>

      {/* Modal de Formulário (Criar/Editar) */}
      <ModalForm
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={isEditMode ? "Editar Produto" : "Novo Produto"}
        description={isEditMode ? "Atualize as informações do produto selecionado." : "Preencha os dados para cadastrar um novo produto no sistema."}
        onSubmit={handleSubmit}
        loading={formLoading}
        isEditMode={isEditMode}
        size="lg"
      >
        <ProductForm 
          ref={productFormRef}
          initialData={currentProduct}
          isLoading={formLoading}
          isEditMode={isEditMode}
        />
      </ModalForm>

      {/* Modal de Gestão de Stock */}
      <ModalForm
        open={stockModalOpen}
        onClose={() => setStockModalOpen(false)}
        title={stockMode === 'adicionar' ? "Adicionar Stock" : "Baixar Stock"}
        description={`Selecione as lojas e as quantidades para ${stockMode === 'adicionar' ? 'aumentar' : 'reduzir'} o stock.`}
        onSubmit={handleStockSubmit}
        loading={formLoading}
        isEditMode={false}
        submitText="Confirmar Movimentação"
      >
        {selectedProductId && (
          <StockForm 
            ref={stockFormRef}
            productId={selectedProductId}
            mode={stockMode}
            productName={products.find(p => p.id === selectedProductId)?.nome}
            isLoading={formLoading}
          />
        )}
      </ModalForm>

      {/* Diálogo de Confirmação de Stock (Logic do código antigo) */}
      <AlertDialog open={stockConfirmOpen} onOpenChange={setStockConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-600" /> Confirmar Operação
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-3 pt-2">
              <p>Tem a certeza que deseja <strong>{stockMode === 'adicionar' ? 'aumentar' : 'baixar'}</strong> o stock nas seguintes lojas:</p>
              <div className="bg-muted p-3 rounded-md space-y-1">
                {stockConfirmData?.distribuicaoStock?.map((item: StockDTO, idx: number) => (
                  <div key={idx} className="flex justify-between text-sm">
                    <span className="font-medium">• {item.storeName}</span>
                    <span>{item.stock} unidade(s)</span>
                  </div>
                ))}
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmStockUpdate} className="bg-green-600 hover:bg-green-700">
              Confirmar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

         {/* Modal de Visualização com Debug (Console e Alert) */}
{viewProduct && (() => {
    // 1. Isso vai imprimir o objeto INTEIRO no console do navegador (F12)
    console.log("DADOS QUE CHEGARAM NA MODAL:", viewProduct);

    // 2. Isso vai mostrar um alerta na tela com o Nome e o Preço que o código está tentando ler
    // alert(`DEBUG: Nome: ${viewProduct.nome} | Preço plural: ${viewProduct.precoUnitarios}`);

    return (
        <GenericViewModal
            open={showViewModal}
            onClose={() => setShowViewModal(false)}
            title="Detalhes do Produto"
            description={`Informações de: ${viewProduct.nome}`}
            image={viewProduct.logoUrl || undefined} 
            fields={[
                { label: "Código de Barras", value: String(viewProduct.codigobarra || "VAZIO") },
                { label: "Nome", value: String(viewProduct.nome || "VAZIO") },
                { label: "Preço Unitário", value: String(viewProduct.precoUnitario || "VAZIO") },
                { label: "Categoria", value: String(viewProduct.categorys || "VAZIO") },
                { label: "Fornecedor", value: String(viewProduct.suppliers || "VAZIO") },
                { label: "Imposto", value: String(viewProduct.taxs || "VAZIO") },
                { label: "Stock Atual", value: String(viewProduct.stock) },
                { label: "Stock Mínimo", value: String(viewProduct.stockMin) },
                { label: "Descrição", value: viewProduct.descricao || "Sem descrição" },
                { label: "Data de Registo", value: String(viewProduct.datacriacao || "VAZIO") },
            ]}
        />
    );
})()}

      {/* Diálogo de Exclusão */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja remover o produto <strong>{deleteProduct?.nome}</strong>? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ProductsPage;
