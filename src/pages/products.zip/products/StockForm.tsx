/**
 * ====================================================
 * STOCK FORM - FORMULÁRIO DE MOVIMENTAÇÃO DE STOCK
 * ====================================================
 */

import { useEffect, useState, forwardRef, useImperativeHandle, useCallback } from 'react'; // React e Hooks
import { useForm } from 'react-hook-form'; // Gestão de formulários
import { zodResolver } from '@hookform/resolvers/zod'; // Integrador Zod
import * as z from 'zod'; // Esquemas de validação
import { Plus, Trash2, Info, Loader2 } from 'lucide-react'; // Ícones

import FormField from '@/components/forms/FormField'; // Componente de input
import { Button } from '@/components/ui/button'; // Botão UI
import { useProductService } from './ProductsService'; // Serviço de API
import { useAuth } from '@/contexts/AuthContext'; // Contexto de login
import { showErrorToast } from '@/utils/toast'; // Notificações
import { Alert, AlertDescription } from "@/components/ui/alert"; // Alerta UI

// --- INTERFACES ---

/** Interface que define a estrutura de uma Loja */
interface Shop { 
  id: number | string; 
  nome: string; 
}

/** Interface para os itens da tabela de distribuição */
interface StockEntry {
  storeId: string | number;
  storeName: string;
  stock: number;
  productId: string | number;
}

/** Esquema de validação para o movimento de stock */
const StockMoveSchema = z.object({
  distribuicaoStock: z.array(z.object({
    storeId: z.union([z.string(), z.number()]),
    storeName: z.string(),
    stock: z.number().min(1, 'Mínimo 1 unidade'),
    productId: z.union([z.string(), z.number()]),
  })).min(1, 'Adicione pelo menos uma unidade'),
});

/** Tipo derivado do esquema Zod */
type StockMoveFormData = z.infer<typeof StockMoveSchema>;

/** Propriedades que o componente recebe */
interface StockFormProps {
  productId: string | number;
  productName?: string;
  mode: 'adicionar' | 'baixar';
  isLoading?: boolean;
}

/** Métodos que o componente expõe para o pai */
export interface StockFormRef {
  trigger: () => Promise<boolean>;
  getValues: () => StockMoveFormData;
}

// --- COMPONENTE ---

const StockForm = forwardRef<StockFormRef, StockFormProps>(({ productId, productName, mode, isLoading }, ref) => {
  
  // Hooks de Contexto e API
  const { user } = useAuth(); 
  const { listarLojasPorProduto, listarLojas } = useProductService();

  // Estados de dados e interface
  const [shops, setShops] = useState<Shop[]>([]); // Lista de lojas disponíveis
  const [selectedShop, setSelectedShop] = useState<Shop | null>(null); // Loja escolhida no select
  const [stockVal, setStockVal] = useState<number>(0); // Quantidade digitada
  const [fetchingShops, setFetchingShops] = useState(true); // Estado de carregamento das lojas

  // Configuração do React Hook Form
  const { trigger, getValues, setValue, watch, formState: { errors } } = useForm<StockMoveFormData>({
    resolver: zodResolver(StockMoveSchema),
    defaultValues: { distribuicaoStock: [] },
  });

  // Observa a lista de movimentos em tempo real
  const distribuicaoStock = watch('distribuicaoStock') || [];

  /**
   * fetchShops: Carrega as lojas baseando-se no contexto (Dono ou Gerente)
   * ✅ CORREÇÃO: Uso de 'const' e lógica condicional para evitar erro de ESLint
   */
  const fetchShops = useCallback(async () => {
    setFetchingShops(true); // Inicia carregamento
    try {
      // 🛡️ Caso 1: Utilizador está numa loja específica (Gerente)
      if (user?.idl && user.idl !== "0") {
        const minhaUnidade: Shop = { id: Number(user.idl), nome: user.loja };
        setShops([minhaUnidade]); // Apenas a sua loja aparece
        setSelectedShop(minhaUnidade); // Pré-seleciona a loja dele
      } 
      // 🌐 Caso 2: Utilizador é o Dono Master (Acesso Global)
      else {
        // Busca lojas que já possuem o produto
        const dataPorProduto = await listarLojasPorProduto(productId);
        
        // Determina a lista final: se a busca por produto falhar ou for vazia no 'adicionar', busca todas as lojas
        let listaFinal: Shop[]; // Declaramos como let pois haverá atribuição condicional
        
        if (!dataPorProduto || dataPorProduto.length === 0) {
          listaFinal = await listarLojas(); // Busca todas as lojas do banco
        } else {
          listaFinal = dataPorProduto; // Usa a lista de quem já tem o produto
        }
        
        setShops(listaFinal); // Atualiza o estado
      }
    } catch (error) {
      showErrorToast("Erro ao sincronizar unidades."); // Feedback de erro
    } finally {
      setFetchingShops(false); // Fim do carregamento
    }
  }, [productId, user, listarLojas, listarLojasPorProduto]);

  // Carrega as lojas ao montar o componente ou mudar o ID do produto
  useEffect(() => {
    fetchShops();
  }, [fetchShops]);

  // Expõe os métodos para o componente pai (ProductsPage)
  useImperativeHandle(ref, () => ({
    trigger,
    getValues
  }));

  /**
   * handleAddEntry: Valida e inclui o movimento na tabela temporária
   */
  const handleAddEntry = () => {
    if (!selectedShop || stockVal <= 0) {
      showErrorToast('Selecione a unidade e informe a quantidade.');
      return;
    }

    if (distribuicaoStock.some(s => s.storeId === selectedShop.id)) {
      showErrorToast('Esta unidade já consta na lista.');
      return;
    }

    // Cria o objeto de entrada tipado
    const newEntry: StockEntry = {
      storeId: selectedShop.id,
      storeName: selectedShop.nome,
      stock: stockVal,
      productId: productId,
    };

    // Atualiza o array no formulário
    setValue('distribuicaoStock', [...distribuicaoStock, newEntry]);
    
    // Se for Admin Global (idl 0), limpa o select para nova escolha. Se gerente, mantém fixo.
    if (user?.idl === "0") {
      setSelectedShop(null);
    }
    setStockVal(0); // Reseta a quantidade para zero
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      
      {/* Banner Informativo de Contexto */}
      <Alert className={mode === 'baixar' ? "bg-orange-50 border-orange-200" : "bg-blue-50 border-blue-200"}>
        <Info className={`w-4 h-4 ${mode === 'baixar' ? "text-orange-600" : "text-blue-600"}`} />
        <AlertDescription className="text-sm font-medium">
          {mode === 'baixar' ? 'Removendo quantidades de:' : 'Adicionando quantidades em:'} 
          <span className="ml-1 font-bold underline">{productName || 'Produto Selecionado'}</span>
        </AlertDescription>
      </Alert>

      {/* Grid de Configuração do Movimento */}
      <div className="grid grid-cols-12 gap-4 items-end bg-muted/30 p-4 rounded-xl border border-slate-200 shadow-inner">
        <div className="col-span-12 md:col-span-5">
          <FormField
            name="loja_estoque"
            label="Unidade de Destino"
            type="select"
            options={shops.map(s => ({ label: s.nome, value: String(s.id) }))}
            value={selectedShop?.id ? String(selectedShop.id) : ''}
            onSelectChange={(id) => {
              const shop = shops.find(s => String(s.id) === id);
              setSelectedShop(shop || null);
            }}
            // ✅ Tranca o seletor se for um Gerente logado na sua unidade
            disabled={isLoading || fetchingShops || (user?.idl !== "0")}
          />
        </div>
        
        <div className="col-span-12 md:col-span-4">
          <FormField
            name="quantidade_mov"
            label={mode === 'baixar' ? "Qtd a Baixar" : "Qtd a Somar"}
            type="number"
            value={stockVal}
            onChange={(e) => setStockVal(Number(e.target.value))}
            disabled={isLoading}
          />
        </div>

        <div className="col-span-12 md:col-span-3">
          <Button 
            type="button" 
            onClick={handleAddEntry} 
            className="w-full h-11 bg-white border-slate-200 hover:bg-slate-50 font-bold" 
            variant="outline" 
            disabled={isLoading || fetchingShops}
          >
            {fetchingShops ? <Loader2 className="animate-spin" /> : "Incluir Movimento"}
          </Button>
        </div>
      </div>

      {/* Tabela de Itens Pendentes para Salvar */}
      <div className="border rounded-xl overflow-hidden bg-white shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 border-b">
            <tr className="text-[10px] font-black uppercase text-slate-500">
              <th className="px-4 py-3 text-left">Unidade</th>
              <th className="px-4 py-3 text-center">Quantidade</th>
              <th className="px-4 py-3 text-center w-16">Acções</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {distribuicaoStock.length === 0 ? (
              <tr>
                <td colSpan={3} className="px-4 py-12 text-center text-slate-400 italic">
                  Utilize o formulário acima para adicionar movimentos à lista.
                </td>
              </tr>
            ) : (
              distribuicaoStock.map((item, index) => (
                <tr key={index} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-4 py-3 font-medium text-slate-700">{item.storeName}</td>
                  <td className="px-4 py-3 text-center font-black text-blue-600 italic">
                    {mode === 'baixar' ? '-' : '+'}{item.stock}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => setValue('distribuicaoStock', distribuicaoStock.filter((_, i) => i !== index))} 
                      className="text-red-400 hover:text-red-600 rounded-full h-8 w-8"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
});

StockForm.displayName = 'StockForm'; // Nome para debug do React
export default StockForm; // Exporta o componente