/**
 * ====================================================
 * PRODUCT FORM - FORMULÁRIO DE PRODUTO PROFISSIONAL
 * ====================================================
 * 
 * Responsável pela criação e edição de produtos com:
 * - Validação rigorosa via Zod.
 * - Fluxo dinâmico (pula etapas se não houver controlo de stock).
 * - Gestão multi-loja.
 * - Tipagem estrita (Strict TypeScript).
 */

import { useEffect, useState, forwardRef, useImperativeHandle, useCallback } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Plus, Trash2, ArrowLeft, ArrowRight, Package, ShieldCheck } from 'lucide-react';

import FormField from '@/components/forms/FormField';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Label } from '@/components/ui/label';
import { useProductService, type ProductFormData, type StockDTO } from './ProductsService';
import { showErrorToast } from '@/utils/toast';

// ====================================================
// INTERFACES DE DADOS (STRICT TYPING)
// ====================================================

interface Category { id: string | number; nome: string; }
interface Supplier { id: string | number; nome: string; }
interface Tax { id: string | number; imposto: string; }
interface Shop { id: string | number; nome: string; }

// ====================================================
// ESQUEMA DE VALIDAÇÃO ZOD
// ====================================================

export const ProductSchema = z.object({
  codigobarra: z.string().min(1, 'Código de Barra é obrigatório'),
  nome: z.string().min(1, 'Nome é obrigatório'),
  descricao: z.string().max(150, 'Máximo 150 caracteres').nullable().optional(),
  precoUnitario: z.string().min(1, 'Preço é obrigatório'),
  controlaStock: z.boolean().default(true),
  
  categoria: z.object({
    id: z.union([z.string(), z.number()]),
    nome: z.string(),
  }).nullable().refine(val => val !== null, 'Categoria é obrigatória'),
  
  fornacedor: z.object({
    id: z.union([z.string(), z.number()]),
    nome: z.string(),
  }).nullable().refine(val => val !== null, 'Fornecedor é obrigatório'),
  
  imposto: z.object({
    id: z.union([z.string(), z.number()]),
    nome: z.string(),
  }).nullable().refine(val => val !== null, 'Imposto é obrigatório'),
  
  imagem: z.instanceof(File).nullable().optional(),
  distribuicaoStock: z.array(z.object({
    storeId: z.union([z.string(), z.number()]),
    storeName: z.string(),
    stock: z.number().min(0),
    stockMin: z.number().min(0),
  })).optional().default([]),
});

interface ProductFormProps {
  initialData?: ProductFormData;
  isLoading?: boolean;
  isEditMode?: boolean;
}

export interface ProductFormRef {
  trigger: () => Promise<boolean>;
  getValues: () => ProductFormData;
  resetStep: () => void;
}

// ====================================================
// COMPONENTE PRINCIPAL
// ====================================================

const ProductForm = forwardRef<ProductFormRef, ProductFormProps>(({ initialData, isLoading, isEditMode }, ref) => {
  
  // 1. INICIALIZAÇÃO DO FORMULÁRIO (Deve ser o primeiro Hook de estado do form)
  const { control, trigger, getValues, reset, watch, setValue, formState: { errors } } = useForm<ProductFormData>({
    resolver: zodResolver(ProductSchema),
    defaultValues: initialData || {
      nome: '',
      codigobarra: '',
      descricao: '',
      precoUnitario: '',
      controlaStock: true,
      categoria: null,
      fornacedor: null,
      imposto: null,
      imagem: null,
      distribuicaoStock: [],
    },
    mode: 'onChange',
  });

  // 2. ESTADOS DE NAVEGAÇÃO E DADOS AUXILIARES
  const [step, setStep] = useState(0);
  const [categories, setCategories] = useState<Category[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [taxes, setTaxes] = useState<Tax[]>([]);
  const [shops, setShops] = useState<Shop[]>([]);
  
  const [selectedShop, setSelectedShop] = useState<Shop | null>(null);
  const [stockVal, setStockVal] = useState<number>(0);
  const [stockMinVal, setStockMinVal] = useState<number>(0);
  const [precoUnitarios, setPrecoUnitarios] = useState<number>(0);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  // 3. OBSERVAÇÃO DE CAMPOS EM TEMPO REAL
  const isStockEnabled = watch('controlaStock');
  const distribuicaoStock = watch('distribuicaoStock') || [];
  const totalSteps = isEditMode || !isStockEnabled ? 2 : 3;

  const { listarCategorias, listarFornecedores, listarImpostos, listarLojas } = useProductService();

  // 4. EFEITO: Carregar dados das APIs
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [cats, supps, imps, lojas] = await Promise.all([
          listarCategorias(),
          listarFornecedores(),
          listarImpostos(),
          listarLojas()
        ]);
        setCategories(cats);
        setSuppliers(supps);
        setTaxes(imps);
        setShops(lojas);
      } catch (error) {
        console.error('Erro ao carregar dados auxiliares:', error);
      }
    };
    fetchData();
  }, []);

  // 5. EFEITO: Sincronizar Edição e Limpeza de Stock
  useEffect(() => {
    if (initialData) {
      reset(initialData);
      if (typeof initialData.imagem === 'string') setImagePreview(initialData.imagem);
    }
  }, [initialData, reset]);

  // Se o utilizador desmarcar "Gerir Stock", limpamos a lista para não enviar dados contraditórios
  useEffect(() => {
    if (!isStockEnabled && distribuicaoStock.length > 0) {
      setValue('distribuicaoStock', []);
    }
  }, [isStockEnabled, setValue, distribuicaoStock.length]);

  // 6. MÉTODOS EXPOSTOS PARA O COMPONENTE PAI (ProductsPage)
  useImperativeHandle(ref, () => ({
    trigger,
    getValues,
    resetStep: () => setStep(0),
  }));

  // 7. GESTÃO DE TABELA DE STOCK
  const handleAddStock = useCallback(() => {
    if (!selectedShop) {
      showErrorToast('Selecione uma loja primeiro.');
      return;
    }
    if (stockVal < stockMinVal) {
      showErrorToast('Stock atual não pode ser menor que o mínimo.');
      return;
    }
    if (distribuicaoStock.some(s => s.storeId === selectedShop.id)) {
      showErrorToast('Esta loja já está na lista.');
      return;
    }

    const newStock: StockDTO = {
      storeId: selectedShop.id,
      storeName: selectedShop.nome,
      stock: stockVal,
      stockMin: stockMinVal,
      precoUnitario:precoUnitarios,
    };

    setValue('distribuicaoStock', [...distribuicaoStock, newStock]);
    setSelectedShop(null);
    setStockVal(0);
    setStockMinVal(0);
  }, [selectedShop, stockVal, stockMinVal, distribuicaoStock, setValue]);

  const handleRemoveStock = (index: number) => {
    const newList = distribuicaoStock.filter((_, i) => i !== index);
    setValue('distribuicaoStock', newList);
  };

  const nextStep = async () => {
    let fields: Array<keyof ProductFormData> = [];
    if (step === 0) fields = ['codigobarra', 'nome'];
    if (step === 1) fields = ['precoUnitario', 'categoria', 'fornacedor', 'imposto'];
    
    const isValid = await trigger(fields);
    if (isValid) setStep(prev => prev + 1);
  };

  return (
    <div className="space-y-6">
      <Progress value={((step + 1) / totalSteps) * 100} className="h-2 transition-all" />
      
      <div className="min-h-[350px]">
        {/* PASSO 0: IDENTIFICAÇÃO E FOTO */}
        {step === 0 && (
          <div className="grid grid-cols-12 gap-6 animate-in fade-in slide-in-from-right-4 duration-300">
            <div className={isEditMode ? "col-span-12 space-y-4" : "col-span-12 md:col-span-9 space-y-4"}>
              <Controller
                name="codigobarra"
                control={control}
                render={({ field }) => (
                  <FormField label="Código de Barra *" placeholder="Ex: 560123456789" {...field} error={errors.codigobarra?.message} />
                )}
              />
              <Controller
                name="nome"
                control={control}
                render={({ field }) => (
                  <FormField label="Nome do Produto *" placeholder="Nome comercial do item" {...field} error={errors.nome?.message} />
                )}
              />
            </div>

            {!isEditMode && (
              <div className="col-span-12 md:col-span-3 flex flex-col items-center justify-center gap-2">
                <Label className="text-[10px] font-bold uppercase text-muted-foreground">Imagem do Produto</Label>
                <div className="w-32 h-32 border-2 border-dashed border-blue-200 rounded-2xl flex items-center justify-center overflow-hidden bg-blue-50/30 relative hover:border-blue-400 transition-colors">
                  {imagePreview ? (
                    <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <Plus className="w-8 h-8 text-blue-300" />
                  )}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setValue('imagem', file);
                        setImagePreview(URL.createObjectURL(file));
                      }
                    }}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>
              </div>
            )}

            <div className="col-span-12">
              <Controller
                name="descricao"
                control={control}
                render={({ field }) => (
                  <FormField 
                    label="Descrição" 
                    type="textarea" 
                    placeholder="Detalhes técnicos ou observações..." 
                    {...field} 
                    value={field.value || ''} 
                    error={errors.descricao?.message} 
                  />
                )}
              />
            </div>
          </div>
        )}

        {/* PASSO 1: FINANCEIRO E DEFINIÇÃO DE STOCK */}
        {step === 1 && (
          <div className="grid grid-cols-12 gap-6 animate-in fade-in slide-in-from-right-4 duration-300">
            <div className="col-span-12 md:col-span-6">
              <Controller
                name="precoUnitario"
                control={control}
                render={({ field }) => (
                  <FormField label="Preço de Venda (Db) *" placeholder="0.00" {...field} error={errors.precoUnitario?.message} />
                )}
              />
            </div>
            <div className="col-span-12 md:col-span-6">
              <Controller
                name="categoria"
                control={control}
                render={({ field }) => (
                  <FormField
                  name="categoria"
                    label="Categoria *"
                    type="select"
                    options={categories.map(c => ({ label: c.nome, value: String(c.id) }))}
                    value={field.value?.id ? String(field.value.id) : ''}
                    onSelectChange={(id) => {
                      const cat = categories.find(c => String(c.id) === id);
                      field.onChange(cat ? { id: cat.id, nome: cat.nome } : null);
                    }}
                    error={errors.categoria?.message}
                  />
                )}
              />
            </div>
            <div className="col-span-12 md:col-span-6">
              <Controller
                name="imposto"
                control={control}
                render={({ field }) => (
                  <FormField
                  name="imposto"
                    label="Taxa de Imposto *"
                    type="select"
                    options={taxes.map(t => ({ label: t.imposto, value: String(t.id) }))}
                    value={field.value?.id ? String(field.value.id) : ''}
                    onSelectChange={(id) => {
                      const imp = taxes.find(t => String(t.id) === id);
                      field.onChange(imp ? { id: imp.id, nome: imp.imposto } : null);
                    }}
                    error={errors.imposto?.message}
                  />
                )}
              />
            </div>
            <div className="col-span-12 md:col-span-6">
              <Controller
                name="fornacedor"
                control={control}
                render={({ field }) => (
                  <FormField
                  name="fornacedor"
                    label="Fornecedor Principal *"
                    type="select"
                    options={suppliers.map(s => ({ label: s.nome, value: String(s.id) }))}
                    value={field.value?.id ? String(field.value.id) : ''}
                    onSelectChange={(id) => {
                      const sup = suppliers.find(s => String(s.id) === id);
                      field.onChange(sup ? { id: sup.id, nome: sup.nome } : null);
                    }}
                    error={errors.fornacedor?.message}
                  />
                )}
              />
            </div>

            {/* SELETOR DE CONFIGURAÇÃO DE INVENTÁRIO */}
       {/* SELETOR DE CONFIGURAÇÃO DE INVENTÁRIO (REFEITO) */}
<div className="col-span-12 mt-6">
  <div className={`
    p-4 rounded-xl border-2 transition-all duration-200
    ${isStockEnabled 
      ? 'bg-slate-50 border-blue-200' 
      : 'bg-amber-50/50 border-amber-200'}
  `}>
    <div className="flex items-center justify-between gap-4">
      <div className="flex items-center gap-4">
        {/* Ícone com fundo circular */}
        <div className={`
          p-3 rounded-full 
          ${isStockEnabled ? 'bg-blue-100 text-blue-600' : 'bg-amber-100 text-amber-600'}
        `}>
          {isStockEnabled ? <Package size={22} /> : <ShieldCheck size={22} />}
        </div>

        {/* Textos Informativos */}
        <div className="flex flex-col">
          <span className={`text-sm font-black uppercase tracking-tight ${isStockEnabled ? 'text-blue-900' : 'text-amber-900'}`}>
            {isStockEnabled ? 'Gestão de Stock Ativa' : 'Produto de Fluxo Livre'}
          </span>
          <span className="text-[11px] text-slate-500 leading-tight max-w-[320px]">
            {isStockEnabled 
              ? 'O sistema validará as quantidades e bloqueará vendas sem stock.'
              : 'Ideal para serviços. Permite vendas ilimitadas sem controlo de armazém.'}
          </span>
        </div>
      </div>

      {/* Botão Switch (Logica Simples) */}
      <Controller
        name="controlaStock"
        control={control}
        render={({ field }) => (
          <button
            type="button"
            onClick={() => field.onChange(!field.value)}
            className={`
              relative inline-flex h-7 w-12 items-center rounded-full transition-colors focus:outline-none
              ${field.value ? 'bg-blue-600' : 'bg-slate-300'}
            `}
          >
            <span
              className={`
                inline-block h-5 w-5 transform rounded-full bg-white transition-transform duration-200
                ${field.value ? 'translate-x-6' : 'translate-x-1'}
              `}
            />
          </button>
        )}
      />
    </div>
  </div>
</div>
          </div>
        )}

        {/* PASSO 2: DISTRIBUIÇÃO FÍSICA (Só se controlar stock) */}
        {step === 2 && isStockEnabled && !isEditMode && (
          <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
            <div className="grid grid-cols-12 gap-3 items-end bg-muted/50 p-4 rounded-xl border border-border">
              <div className="col-span-12 md:col-span-4">
                <FormField
                 name="loja_selecionada"
                  label="Loja de Destino"
                  type="select"
                  options={shops.map(s => ({ label: s.nome, value: String(s.id) }))}
                  value={selectedShop?.id ? String(selectedShop.id) : ''}
                  onSelectChange={(id) => {
                    const shop = shops.find(s => String(s.id) === id);
                    setSelectedShop(shop ? { id: shop.id, nome: shop.nome } : null);
                  }}
                />
              </div>
              <div className="col-span-6 md:col-span-3">
                
                <FormField   name="temp_stock" label="Qtd Inicial" type="number" value={stockVal} onChange={(e) => setStockVal(Number(e.target.value))} />
              </div>
              <div className="col-span-6 md:col-span-3">
                <FormField   name="temp_stock_min" label="Mínimo Alerta" type="number" value={stockMinVal} onChange={(e) => setStockMinVal(Number(e.target.value))} />
              </div>
                <div className="col-span-6 md:col-span-3">
                <FormField   name="precoUnitario" label="Preço Unitário" type="number" value={precoUnitarios} onChange={(e) => setPrecoUnitarios(Number(e.target.value))} />
              </div>
              <div className="col-span-12 md:col-span-2">
                <Button type="button" onClick={handleAddStock} className="w-full bg-blue-600 hover:bg-blue-700">
                   Adicionar
                </Button>
              </div>
            </div>

            <div className="border rounded-xl overflow-hidden shadow-sm">
              <table className="w-full text-xs">
                <thead className="bg-slate-50 border-b">
                  <tr>
                    <th className="px-4 py-3 text-left font-bold uppercase text-slate-500">Unidade/Loja</th>
                    <th className="px-4 py-3 text-center font-bold uppercase text-slate-500">Stock</th>
                    <th className="px-4 py-3 text-center font-bold uppercase text-slate-500">Min.</th>
                    <th className="px-4 py-3 text-center font-bold uppercase text-slate-500">Preço Unitário</th>
                    <th className="px-4 py-3 text-center w-16"></th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {distribuicaoStock.length === 0 ? (
                    <tr><td colSpan={4} className="px-4 py-10 text-center text-slate-400 italic font-medium">Nenhuma distribuição configurada.</td></tr>
                  ) : (
                    distribuicaoStock.map((item, index) => (
                      <tr key={index} className="hover:bg-blue-50/30 transition-colors">
                        <td className="px-4 py-3 font-bold text-slate-700">{item.storeName}</td>
                        <td className="px-4 py-3 text-center font-black text-blue-600">{item.stock}</td>
                        <td className="px-4 py-3 text-center font-medium text-red-400">{item.stockMin}</td>
                        <td className="px-4 py-3 text-center font-medium text-slate-500">{item.precoUnitario}</td>
                        <td className="px-4 py-3 text-center">
                          <Button variant="ghost" size="icon" onClick={() => handleRemoveStock(index)} className="h-7 w-7 text-red-400 hover:text-red-600">
                             <Trash2 size={14} />
                          </Button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* RODAPÉ DE NAVEGAÇÃO */}
      <div className="flex justify-between items-center pt-6 border-t mt-4">
        <Button
          type="button"
          variant="ghost"
          onClick={() => setStep(prev => prev - 1)}
          disabled={step === 0 || isLoading}
          className="font-bold text-slate-500"
        >
          <ArrowLeft className="w-4 h-4 mr-2" /> Anterior
        </Button>
        
        {step < totalSteps - 1 ? (
          <Button type="button" onClick={nextStep} disabled={isLoading} className="px-8 font-bold bg-slate-900">
            Continuar <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        ) : (
          <div className="flex items-center gap-2 text-blue-600 bg-blue-50 px-4 py-2 rounded-full border border-blue-100 animate-pulse">
            <ShieldCheck size={16} />
            <span className="text-[10px] font-black uppercase tracking-widest">
               Pronto para {isEditMode ? 'Atualizar' : 'Guardar'}
            </span>
          </div>
        )}
      </div>
    </div>
  );
});

ProductForm.displayName = 'ProductForm';
export default ProductForm;