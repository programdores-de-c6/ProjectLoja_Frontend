/**
 * ====================================================
 * PRODUCT SERVICE - VERSÃO OTIMIZADA (JWT INTEGRADO)
 * ====================================================
 * 
 * Este serviço comunica com a API de produtos.
 * Removida a redundância de enviar IDs de utilizador e loja, 
 * pois o Backend agora extrai estas informações do Token JWT.
 */

import api from '@/config/api';
import { showErrorToast } from '@/utils/toast';

// ====================================================
// INTERFACES E TIPOS DE DADOS
// ====================================================

/** Representa a estrutura de stock para envio/recebimento */
export interface StockDTO {
  storeId: string | number;
  storeName?: string;
  stock: number;
  stockMin?: number;
  productId?: string | number;
  precoUnitario?: number; 
}

/** Interface principal do Produto vinda da API */
export interface Product {
  id: string | number;
  codigobarra: string;
  controlaStock: boolean;
  nome: string;
  descricao: string | null;
  //precoUnitario: string | number;
  stock: number;
  stockMin: number;
  datacriacao: string;
  idsupplier?: string | number;
  suppliers?: string;
  idcatgory?: string | number;
  categorys?: string;
  idtax?: string | number;
  taxs?: string;
  taxa?: number;
  logoUrl?: string | null;
}

/** Estrutura de dados para o formulário de criação/edição */
export interface ProductFormData {
  id?: string | number;
  nome: string;
  controlaStock: boolean;
  codigobarra: string;
  descricao: string | null;
  precoUnitario: string;
  categoria: { id: string | number; nome: string } | null;
  fornacedor: { id: string | number; nome: string } | null;
  imposto: { id: string | number; nome: string } | null;
  imagem?: File | string | null;
  distribuicaoStock?: StockDTO[];
}

// ====================================================
// HOOK CUSTOMIZADO: useProductService
// ====================================================

export const useProductService = () => {

  /**
   * Mapeia os dados do formulário para o DTO limpo esperado pelo Backend.
   * ✅ REMOVIDO: Objeto 'employee' e 'shopId' manual.
   */
  const mapToDTO = (data: ProductFormData) => {
    // Converte o preço formatado (Db 1.000,00) para número puro
    const valorFormatado = typeof data.precoUnitario === 'string' 
      ? parseFloat(data.precoUnitario.replace(/[^\d,.-]/g, "").replace(/\./g, "").replace(",", "."))
      : data.precoUnitario;

    return {
      id: data.id,
      codigobarra: data.codigobarra,
      nome: data.nome,
      descricao: data.descricao,
      precoUnitario: valorFormatado,
      controlaStock: data.controlaStock,
      // Mapeamento de objetos simples para o Spring Boot converter em Entidades
      category: data.categoria ? { id: data.categoria.id } : null,
      supplier: data.fornacedor ? { id: data.fornacedor.id } : null,
      tax: data.imposto ? { id: data.imposto.id } : null,
      // O Backend usará o Token para definir o Employee e a Shop automaticamente
      stockDTOs: data.controlaStock ? (data.distribuicaoStock || []) : []
    };
  };

  /**
   * Lista produtos filtrados pela loja do Token.
   */
  const listar = async (): Promise<Product[]> => {
    try {
      const res = await api.get('/product/list');
      return res.data;
    } catch (error) {
      console.error('Erro ao listar:', error);
      showErrorToast('Erro ao carregar lista de produtos.');
      throw error;
    }
  };

  /**
   * Detalhes de um produto específico.
   */
  const listarId = async (id: string | number): Promise<Product> => {
    try {
      const res = await api.get(`/product/listid/${id}`);
      return res.data;
    } catch (error) {
      showErrorToast('Erro ao carregar detalhes do produto.');
      throw error;
    }
  };

  /**
   * Criação com Upload de Imagem.
   * O DTO enviado via Blob agora está muito mais limpo.
   */
  const criar = async (data: ProductFormData): Promise<Product> => {
    try {
      const formData = new FormData();
      
      // Anexa o ficheiro de imagem se existir
      if (data.imagem instanceof File) {
        formData.append('file', data.imagem);
      }

      // Constrói o DTO sem dados de utilizador/loja (Segurança JWT)
      const dto = mapToDTO(data);
      formData.append(
        'productDTO',
        new Blob([JSON.stringify(dto)], { type: 'application/json' })
      );

      const res = await api.post('/product/create', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      return res.data;
    } catch (error) {
      showErrorToast('Falha ao registar produto.');
      throw error;
    }
  };

  /**
   * Atualização de dados cadastrais.
   */
  const editar = async (data: ProductFormData): Promise<Product> => {
    try {
      const dto = mapToDTO(data);
      const res = await api.put('/product/update', dto);
      return res.data;
    } catch (error) {
      showErrorToast('Erro ao atualizar informações.');
      throw error;
    }
  };

  /**
   * Movimentação manual de Stock (Entrada/Baixa).
   */
  const updateStock = async (payload: { acao: string, distribuicaoStock: StockDTO[] }): Promise<Product> => {
    try {
      const dto = {
        acao: payload.acao,
        stockDTOs: payload.distribuicaoStock.map(item => ({
          storeId: item.storeId,
          stock: item.stock,
          product: item.productId
        }))
      };
      const res = await api.put('/product/updatestock', dto);
      return res.data;
    } catch (error) {
      showErrorToast('Não foi possível ajustar o stock.');
      throw error;
    }
  };

  /**
   * Eliminação de produto.
   */
  const deletar = async (id: string | number): Promise<void> => {
    try {
      await api.delete('/product/delete', { params: { id } });
    } catch (error) {
      showErrorToast('Erro ao remover item do catálogo.');
      throw error;
    }
  };

  // Funções de carregamento de listas para Selects (Comboboxes)
  const listarCategorias = async () => (await api.get('/category/list')).data;
  const listarFornecedores = async () => (await api.get('/supplier/list')).data;
  const listarImpostos = async () => (await api.get('/tax/list')).data;
  const listarLojas = async () => (await api.get('/shop/list')).data;

  /**
   * Filtra lojas que possuem o item (útil para transferências ou baixas).
   */
  const listarLojasPorProduto = async (productId: string | number) => {
    try {
      const res = await api.get('/shop/list-by-product', { params: { productId } });
      return res.data;
    } catch (error) {
      return []; 
    }
  };

  return {
    listar,
    listarId,
    criar,
    editar,
    deletar,
    updateStock,
    listarCategorias,
    listarFornecedores,
    listarImpostos,
    listarLojas,
    listarLojasPorProduto
  };
};